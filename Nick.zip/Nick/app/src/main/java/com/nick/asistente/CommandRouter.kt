package com.nick.asistente

import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.ContactsContract
import android.provider.MediaStore

/** Entiende órdenes en español y las convierte en acciones del teléfono. */
class CommandRouter(private val ctx: Context) {

    private val whatsappRx = Regex(
        """(?:whatsapp|mand[aá]le(?: un mensaje)?|escr[ií]bele|escr[ií]bile)\s+(?:a\s+)?(.+?)\s*(?:que dice|diciendo|que|:)\s+(.+)""",
        RegexOption.IGNORE_CASE
    )
    private val playRx = Regex(
        """^(?:reproduce|reproduc[ií]|pon|pone|poné|ponme)\s+(.+)""",
        RegexOption.IGNORE_CASE
    )
    private val fileRx = Regex(
        """^(?:busca|buscá|encuentra)\s+(?:el |la |un |una )?(?:archivo|documento|foto|video|audio|canción)\s+(.+)""",
        RegexOption.IGNORE_CASE
    )

    fun handle(text: String): String {
        val t = text.trim()
        whatsappRx.find(t)?.let { return sendWhatsApp(it.groupValues[1].trim(), it.groupValues[2].trim()) }
        playRx.find(t)?.let { return play(it.groupValues[1].trim()) }
        fileRx.find(t)?.let { return openFile(it.groupValues[1].trim()) }
        return "No entendí esa orden todavía."
    }

    // ---- WhatsApp ----
    private fun sendWhatsApp(target: String, message: String): String {
        val looksLikeNumber = Regex("""^[+\d][\d\s-]{6,}$""").matches(target)
        val raw = if (looksLikeNumber) target else lookupContact(target)
            ?: return "No encontré el contacto \"$target\"."
        val number = raw.filter { it.isDigit() }
        val url = "https://wa.me/$number?text=" + Uri.encode(message)
        return try {
            start(Intent(Intent.ACTION_VIEW, Uri.parse(url)).setPackage("com.whatsapp"))
            "Abrí WhatsApp con el mensaje listo para $target. Tocá enviar."
        } catch (e: Exception) {
            try {
                start(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                "Abrí el enlace de WhatsApp para $target."
            } catch (e2: Exception) {
                "No pude abrir WhatsApp."
            }
        }
    }

    private fun lookupContact(name: String): String? = try {
        ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
            arrayOf("%$name%"),
            null
        )?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
    } catch (e: SecurityException) {
        null
    }

    // ---- Reproducir ----
    private fun play(query: String): String {
        val url = "https://www.youtube.com/results?search_query=" + Uri.encode(query)
        return try {
            start(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
            "Buscando \"$query\" en YouTube."
        } catch (e: Exception) {
            "No pude abrir YouTube."
        }
    }

    // ---- Buscar archivo ----
    private fun openFile(name: String): String {
        val uri = MediaStore.Files.getContentUri("external")
        return try {
            ctx.contentResolver.query(
                uri,
                arrayOf(
                    MediaStore.Files.FileColumns._ID,
                    MediaStore.Files.FileColumns.DISPLAY_NAME,
                    MediaStore.Files.FileColumns.MIME_TYPE
                ),
                "${MediaStore.Files.FileColumns.DISPLAY_NAME} LIKE ?",
                arrayOf("%$name%"),
                "${MediaStore.Files.FileColumns.DATE_MODIFIED} DESC"
            )?.use { c ->
                if (!c.moveToFirst()) return "No encontré ningún archivo con \"$name\"."
                val id = c.getLong(0)
                val found = c.getString(1)
                val mime = c.getString(2) ?: "*/*"
                val fileUri = ContentUris.withAppendedId(uri, id)
                start(
                    Intent(Intent.ACTION_VIEW)
                        .setDataAndType(fileUri, mime)
                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                )
                "Abriendo $found"
            } ?: "No pude buscar archivos."
        } catch (e: Exception) {
            "No pude abrir el archivo (¿diste permiso de archivos?)."
        }
    }

    private fun start(i: Intent) {
        ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}
